package com.vidal.creatorvault.util

import java.io.InputStream
import java.security.MessageDigest

object HashUtils {
    fun calculateSha256(inputStream: InputStream): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(8192)
            var bytesRead: Int
            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            null
        } finally {
            inputStream.close()
        }
    }

    fun calculateSha256(file: java.io.File): String? {
        return calculateSha256(file.inputStream())
    }
}
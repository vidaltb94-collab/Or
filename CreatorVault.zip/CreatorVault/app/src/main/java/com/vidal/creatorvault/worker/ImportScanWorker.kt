package com.vidal.creatorvault.worker

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.work.*
import com.vidal.creatorvault.data.AppDatabase
import com.vidal.creatorvault.data.VaultRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class ImportScanWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val repo = VaultRepository(applicationContext, AppDatabase.getDatabase(applicationContext))
        var imported = 0
        var failed = 0

        try {
            // Scan recent images and videos from known sources
            val sources = listOf(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI to "Screenshots",
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI to "Movies"
                // Add more specific queries for CapCut, Downloads etc in full impl
            )

            sources.forEach { (uri, sourceName) ->
                val projection = arrayOf(
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.DATE_ADDED
                )
                // Only recent (last 7 days for demo, real uses last scan timestamp from DataStore)
                val selection = "${MediaStore.MediaColumns.DATE_ADDED} > ?"
                val selectionArgs = arrayOf(((System.currentTimeMillis() / 1000) - 7 * 24 * 3600).toString())

                applicationContext.contentResolver.query(
                    uri,
                    projection,
                    selection,
                    selectionArgs,
                    "${MediaStore.MediaColumns.DATE_ADDED} DESC"
                )?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID))
                        val contentUri = Uri.withAppendedPath(uri, id.toString())
                        
                        val result = repo.importMediaFile(contentUri, sourceName)
                        if (result.isSuccess) imported++ else failed++
                        
                        if (imported > 50) break // safety limit per run
                    }
                }
            }

            // Also handle custom SAF persisted folders if stored in prefs (omitted for brevity)

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun scheduleOneTimeScan(context: Context) {
            val request = OneTimeWorkRequestBuilder<ImportScanWorker>()
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }

        fun schedulePeriodic(context: Context) {
            val periodic = PeriodicWorkRequestBuilder<ImportScanWorker>(6, TimeUnit.HOURS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiresBatteryNotLow(true)
                        .build()
                )
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "creatorvault_periodic_scan",
                ExistingPeriodicWorkPolicy.KEEP,
                periodic
            )
        }
    }
}
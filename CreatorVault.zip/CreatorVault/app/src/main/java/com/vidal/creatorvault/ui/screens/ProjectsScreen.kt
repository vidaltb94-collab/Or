package com.vidal.creatorvault.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ProjectsScreen(
    onCreateProject: (String) -> Unit,
    onOpenProject: (String) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Proyectos", style = MaterialTheme.typography.headlineSmall)
            Button(onClick = { showCreateDialog = true }) {
                Text("Crear")
            }
        }
        
        Spacer(Modifier.height(16.dp))
        
        // Demo projects
        ElevatedCard {
            ListItem(
                headlineContent = { Text("Campaña Verano 2026") },
                supportingContent = { Text("12 archivos · 3 finales exportados") },
                trailingContent = { TextButton(onClick = { onOpenProject("demo1") }) { Text("Abrir") } }
            )
        }
        Spacer(Modifier.height(8.dp))
        ElevatedCard {
            ListItem(
                headlineContent = { Text("Contenido Flow Reel") },
                supportingContent = { Text("87 imágenes · 14 vídeos") },
                trailingContent = { TextButton(onClick = { onOpenProject("demo2") }) { Text("Abrir") } }
            )
        }
        
        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                title = { Text("Nuevo proyecto") },
                text = {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Nombre del proyecto") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (newName.isNotBlank()) onCreateProject(newName)
                        showCreateDialog = false
                        newName = ""
                    }) { Text("Crear") }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) { Text("Cancelar") }
                }
            )
        }
    }
}
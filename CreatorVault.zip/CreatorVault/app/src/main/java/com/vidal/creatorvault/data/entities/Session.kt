package com.vidal.creatorvault.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "sessions")
data class Session(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val startTime: Long,
    val endTime: Long,
    val fileCount: Int = 0,
    val totalSizeBytes: Long = 0,
    val sourcesSummary: String, // e.g. "Flow, Screenshots, CapCut"
    val projectId: String? = null, // if whole session assigned
    val lastUpdated: Long = System.currentTimeMillis()
)
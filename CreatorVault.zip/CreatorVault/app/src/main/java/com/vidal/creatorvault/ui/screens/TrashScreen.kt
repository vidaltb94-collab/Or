package com.vidal.creatorvault.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TrashScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Papelera (48 horas)", style = MaterialTheme.typography.headlineSmall)
        Text("Los elementos se eliminan automáticamente después de 48 horas. Puedes restaurar en cualquier momento.", style = MaterialTheme.typography.bodyMedium)
        
        Spacer(Modifier.height(16.dp))
        
        ElevatedCard {
            Column(Modifier.padding(16.dp)) {
                Text("3 elementos en papelera", style = MaterialTheme.typography.titleMedium)
                Text("Tiempo restante promedio: 41h 12m", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { /* restore all */ }) { Text("Restaurar todo") }
                    OutlinedButton(onClick = { /* empty now with confirmation */ }) { Text("Vaciar ahora") }
                }
            }
        }
        
        Spacer(Modifier.height(24.dp))
        Text("Protección: Los archivos marcados como Favoritos o Versiones Finales nunca se envían automáticamente a papelera.", style = MaterialTheme.typography.bodySmall)
    }
}
package com.vidal.creatorvault.data.dao

import androidx.room.*
import com.vidal.creatorvault.data.entities.Project
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE isArchived = 0 ORDER BY lastModified DESC")
    fun getActiveProjects(): Flow<List<Project>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(project: Project)

    @Update
    suspend fun update(project: Project)

    @Query("UPDATE projects SET isArchived = 1 WHERE id = :id")
    suspend fun archive(id: String)
}
package com.vidal.creatorvault.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import java.io.File

object MediaUtils {
    data class MediaMetadata(
        val mimeType: String,
        val size: Long,
        val dateAdded: Long,
        val width: Int?,
        val height: Int?,
        val duration: Long?,
        val displayName: String?
    )

    fun getMediaMetadata(context: Context, uri: Uri): MediaMetadata? {
        val resolver = context.contentResolver
        val projection = arrayOf(
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DURATION
        )
        resolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val mime = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)) ?: "application/octet-stream"
                val size = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                val date = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)) * 1000L
                val width = cursor.getIntOrNull(MediaStore.MediaColumns.WIDTH)
                val height = cursor.getIntOrNull(MediaStore.MediaColumns.HEIGHT)
                val name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                val dur = cursor.getLongOrNull(MediaStore.MediaColumns.DURATION)
                return MediaMetadata(mime, size, date, width, height, dur, name)
            }
        }
        // Fallback for some URIs
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            val w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            val h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            MediaMetadata("video/*", 0L, System.currentTimeMillis(), w, h, dur, uri.lastPathSegment)
        } catch (e: Exception) { null }
    }

    private fun Int?.orZero() = this ?: 0
    private fun android.database.Cursor.getIntOrNull(column: String): Int? {
        val idx = getColumnIndex(column)
        return if (idx != -1 && !isNull(idx)) getInt(idx) else null
    }
    private fun android.database.Cursor.getLongOrNull(column: String): Long? {
        val idx = getColumnIndex(column)
        return if (idx != -1 && !isNull(idx)) getLong(idx) else null
    }

    // Simple perceptual hash (average hash 8x8 grayscale) for images - good enough for variant detection
    fun computeSimplePerceptualHash(file: File): String? {
        return try {
            val options = BitmapFactory.Options().apply { inSampleSize = 4 }
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, options) ?: return null
            val scaled = Bitmap.createScaledBitmap(bitmap, 8, 8, true)
            val gray = IntArray(64)
            var sum = 0
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val pixel = scaled.getPixel(x, y)
                    val g = ((pixel shr 16 and 0xFF) + (pixel shr 8 and 0xFF) + (pixel and 0xFF)) / 3
                    gray[y * 8 + x] = g
                    sum += g
                }
            }
            val avg = sum / 64
            val hash = StringBuilder()
            for (g in gray) {
                hash.append(if (g > avg) "1" else "0")
            }
            bitmap.recycle()
            scaled.recycle()
            hash.toString()
        } catch (e: Exception) {
            null
        }
    }
}
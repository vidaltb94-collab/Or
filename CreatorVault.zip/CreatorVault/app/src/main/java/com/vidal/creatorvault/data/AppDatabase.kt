package com.vidal.creatorvault.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.vidal.creatorvault.data.dao.MediaItemDao
import com.vidal.creatorvault.data.dao.ProjectDao
import com.vidal.creatorvault.data.dao.SessionDao
import com.vidal.creatorvault.data.entities.MediaItem
import com.vidal.creatorvault.data.entities.Project
import com.vidal.creatorvault.data.entities.Session

@Database(
    entities = [MediaItem::class, Session::class, Project::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaItemDao(): MediaItemDao
    abstract fun sessionDao(): SessionDao
    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "creatorvault_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// Simple converters if needed for future (e.g. lists)
class Converters {
    // Add @TypeConverter methods here if complex types added later
}
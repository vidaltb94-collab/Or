package com.vidal.creatorvault.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(onEnableAutomation: () -> Unit) {
    var automationEnabled by remember { mutableStateOf(false) }
    
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Ajustes", style = MaterialTheme.typography.headlineSmall)
        
        ElevatedCard {
            Column(Modifier.padding(16.dp)) {
                Text("Intervalo de sesión", style = MaterialTheme.typography.titleMedium)
                Text("30 minutos (recomendado). Archivos dentro de esta ventana se agrupan automáticamente.")
                Slider(value = 0.5f, onValueChange = {}, valueRange = 0.1f..2f)
            }
        }
        
        ElevatedCard {
            Column(Modifier.padding(16.dp)) {
                Row {
                    Text("Modo automatización personal", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Switch(checked = automationEnabled, onCheckedChange = { 
                        automationEnabled = it
                        if (it) onEnableAutomation()
                    })
                }
                Text(
                    "Permite eliminar originales automáticamente tras verificar copia SHA-256 + tamaño. Requiere permiso especial MANAGE_EXTERNAL_STORAGE. Desactivado por defecto y no necesario para el funcionamiento normal.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (automationEnabled) {
                    Text("⚠️ Modo avanzado activado. Úsalo solo en APK instalada manualmente y bajo tu control.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // === Professional CapCut Integration Section ===
        ElevatedCard {
            Column(Modifier.padding(16.dp)) {
                Text("Integración con CapCut", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                
                Text(
                    "CreatorVault ofrece la mejor integración posible con CapCut sin depender de APIs no oficiales.",
                    style = MaterialTheme.typography.bodyMedium
                )
                
                Spacer(Modifier.height(8.dp))
                
                Text(
                    "• Crea copias temporales visibles automáticamente\n" +
                    "• Intenta abrir archivos directamente en CapCut\n" +
                    "• Limpieza automática de la bandeja temporal\n" +
                    "• Detección inteligente de si CapCut está instalado",
                    style = MaterialTheme.typography.bodySmall
                )
                
                Spacer(Modifier.height(12.dp))
                
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { /* call CapCutManager.cleanCapCutTray() */ }) {
                        Text("Limpiar bandeja ahora")
                    }
                    Button(onClick = { /* show explanation dialog */ }) {
                        Text("Cómo funciona")
                    }
                }
                
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(com.vidal.creatorvault.R.string.capcut_integration_note),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        Text("La bóveda usa almacenamiento interno privado de la app (/data/data/com.vidal.creatorvault/). Nunca se indexa en Samsung Gallery. Desinstalar la app borrará la bóveda.", style = MaterialTheme.typography.bodySmall)
        
        Text("Creado para uso personal en Samsung Galaxy S25 Ultra. Jetpack Compose + Room + WorkManager + MediaStore + SAF + DocumentsProvider.", style = MaterialTheme.typography.labelSmall)
    }
}
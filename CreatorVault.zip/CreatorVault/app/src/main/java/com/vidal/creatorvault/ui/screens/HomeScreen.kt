package com.vidal.creatorvault.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.vidal.creatorvault.ui.viewmodel.HomeViewModel

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onScanClick: () -> Unit,
    onNavigateToSessions: () -> Unit,
    onNavigateToProjects: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("CreatorVault", style = MaterialTheme.typography.headlineLarge)
            Text("Tu bóveda creativa privada", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        item {
            ElevatedCard {
                Column(Modifier.padding(20.dp)) {
                    Text(
                        text = "Hoy: ${state.todayNewCount} archivos nuevos · ${state.todaySizeGB}",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { if (state.todayNewCount > 0) 0.7f else 0f },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = onNavigateToSessions, label = { Text("${state.pendingSessions} sesiones pendientes") })
                        AssistChip(onClick = {}, label = { Text("${state.unclassified} sin clasificar") })
                    }
                }
            }
        }

        item {
            OutlinedButton(
                onClick = onScanClick,
                modifier = Modifier.fillMaxWidth(),
                enabled = !state.isScanning
            ) {
                if (state.isScanning) {
                    CircularProgressIndicator(Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Escaneando...")
                } else {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Escanear ahora (importación segura)")
                }
            }
            state.lastScanMessage?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
        }

        item {
            Text("Resumen por fuente", style = MaterialTheme.typography.titleMedium)
        }
        // In real would show chips or list from sources flow
        item {
            Text("• Flow / Imágenes generadas\n• CapCut exportaciones\n• Screenshots (prompts)\n• Descargas", style = MaterialTheme.typography.bodyMedium)
        }

        item {
            Text("Proyectos recientes", style = MaterialTheme.typography.titleMedium)
            if (state.recentProjects.isEmpty()) {
                Text("Aún no tienes proyectos. Ve a la pestaña Proyectos para crear uno.", style = MaterialTheme.typography.bodySmall)
            } else {
                state.recentProjects.forEach { p ->
                    ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text("Toca para abrir") })
                }
            }
        }

        item {
            ElevatedCard(onClick = onNavigateToProjects) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Ver todos los proyectos y asignar sesiones", modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ArrowForward, contentDescription = null)
                }
            }
        }
    }
}
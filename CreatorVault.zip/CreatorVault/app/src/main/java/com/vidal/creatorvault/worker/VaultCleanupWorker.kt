package com.vidal.creatorvault.worker

import android.content.Context
import androidx.work.*
import com.vidal.creatorvault.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

class VaultCleanupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(applicationContext)
        val now = System.currentTimeMillis()

        // Delete expired trash (permanent delete after 48h)
        db.mediaItemDao().deleteExpiredTrash(now)

        // Clean old CapCut temp files (older than 24h example)
        val trayDir = File(applicationContext.filesDir, "capcut_tray")
        trayDir.listFiles()?.forEach { f ->
            if (now - f.lastModified() > 24 * 3600 * 1000L) f.delete()
        }

        // Also could clean temp/ dir

        Result.success()
    }

    companion object {
        fun schedulePeriodicCleanup(context: Context) {
            val request = PeriodicWorkRequestBuilder<VaultCleanupWorker>(12, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "vault_cleanup",
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
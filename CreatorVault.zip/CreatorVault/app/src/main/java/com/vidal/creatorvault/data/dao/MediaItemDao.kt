package com.vidal.creatorvault.data.dao

import androidx.room.*
import com.vidal.creatorvault.data.entities.MediaItem
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaItemDao {
    @Query("SELECT * FROM media_items WHERE isInTrash = 0 ORDER BY dateAdded DESC")
    fun getAllActive(): Flow<List<MediaItem>>

    @Query("SELECT * FROM media_items WHERE sessionId = :sessionId AND isInTrash = 0")
    fun getBySession(sessionId: String): Flow<List<MediaItem>>

    @Query("SELECT * FROM media_items WHERE projectId = :projectId AND isInTrash = 0")
    fun getByProject(projectId: String): Flow<List<MediaItem>>

    @Query("SELECT * FROM media_items WHERE isInTrash = 1 AND trashExpiresAt > :now ORDER BY trashExpiresAt ASC")
    fun getTrashItems(now: Long = System.currentTimeMillis()): Flow<List<MediaItem>>

    @Query("SELECT * FROM media_items WHERE hashSha256 = :hash LIMIT 1")
    suspend fun findByHash(hash: String): MediaItem?

    @Query("SELECT COUNT(*) FROM media_items WHERE isInTrash = 0")
    fun getActiveCount(): Flow<Int>

    @Query("SELECT SUM(sizeBytes) FROM media_items WHERE isInTrash = 0")
    fun getTotalSize(): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: MediaItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<MediaItem>)

    @Update
    suspend fun update(item: MediaItem)

    @Query("UPDATE media_items SET isInTrash = 1, trashExpiresAt = :expiresAt, sessionId = NULL WHERE id IN (:ids)")
    suspend fun moveToTrash(ids: List<String>, expiresAt: Long)

    @Query("UPDATE media_items SET isInTrash = 0, trashExpiresAt = NULL WHERE id = :id")
    suspend fun restoreFromTrash(id: String)

    @Query("DELETE FROM media_items WHERE id = :id AND isInTrash = 1")
    suspend fun deletePermanently(id: String)

    @Query("DELETE FROM media_items WHERE isInTrash = 1 AND trashExpiresAt < :now")
    suspend fun deleteExpiredTrash(now: Long = System.currentTimeMillis())

    @Query("UPDATE media_items SET projectId = :projectId, category = :category WHERE id IN (:ids)")
    suspend fun assignToProject(ids: List<String>, projectId: String, category: String = "UNCATEGORIZED")

    @Query("UPDATE media_items SET isFinal = 1 WHERE id IN (:ids)")
    suspend fun markAsFinal(ids: List<String>)

    @Query("UPDATE media_items SET isFavorite = NOT isFavorite WHERE id = :id")
    suspend fun toggleFavorite(id: String)

    @Query("SELECT * FROM media_items WHERE perceptualHash IS NOT NULL AND perceptualHash = :pHash AND id != :excludeId LIMIT 5")
    suspend fun findSimilarByPerceptual(pHash: String, excludeId: String): List<MediaItem>

    @Query("SELECT DISTINCT source FROM media_items WHERE isInTrash = 0")
    fun getAllSources(): Flow<List<String>>
}
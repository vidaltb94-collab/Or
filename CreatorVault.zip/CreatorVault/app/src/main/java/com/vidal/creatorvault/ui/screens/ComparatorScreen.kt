package com.vidal.creatorvault.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ComparatorScreen(onFinish: () -> Unit) {
    var selectedWinners by remember { mutableStateOf(setOf<String>()) }
    
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Comparador de variantes", style = MaterialTheme.typography.headlineSmall)
        Text("Detecta duplicados exactos (SHA-256) y similares (pHash + metadatos). Elige las mejores.", style = MaterialTheme.typography.bodyMedium)
        
        Spacer(Modifier.height(16.dp))
        
        // Demo grid of variants (in real: from ViewModel with perceptual groups)
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(4) { idx ->
                val id = "var$idx"
                ElevatedCard(
                    onClick = {
                        if (id in selectedWinners) selectedWinners -= id else selectedWinners += id
                    },
                    colors = if (id in selectedWinners) CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer) else CardDefaults.elevatedCardColors()
                ) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        // In real: Coil image of thumbnail from vault file
                        Text("Variante ${idx + 1}", style = MaterialTheme.typography.titleMedium)
                        Text(if (idx == 0) "Ganadora sugerida" else "Similar", style = MaterialTheme.typography.bodySmall)
                        Text("1080p · 2.3s · 4.2MB", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        
        Spacer(Modifier.height(24.dp))
        
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onFinish, modifier = Modifier.weight(1f)) {
                Text("Cancelar")
            }
            Button(
                onClick = {
                    // In real: call repo to keep selected, move others to trash with undo snackbar
                    onFinish()
                },
                modifier = Modifier.weight(1f),
                enabled = selectedWinners.isNotEmpty()
            ) {
                Text("Conservar ganadoras (${selectedWinners.size})")
            }
        }
        
        Text("Las no seleccionadas irán a la papelera (48h recuperables). Siempre hay opción de deshacer.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
    }
}
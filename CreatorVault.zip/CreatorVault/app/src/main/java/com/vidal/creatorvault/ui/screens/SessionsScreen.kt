package com.vidal.creatorvault.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SessionsScreen(
    onAssignSession: (String) -> Unit,
    onCompare: () -> Unit,
    onSendToTrash: (List<String>) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text("Sesiones de trabajo", style = MaterialTheme.typography.headlineSmall)
            Text("Agrupadas automáticamente por proximidad temporal (configurable en Ajustes)", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
        }
        
        // Demo session card (in real populated from ViewModel + Flow)
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Hoy · 14:22–15:10", style = MaterialTheme.typography.titleMedium)
                    Text("42 imágenes · 6 vídeos · 2,3 GB", style = MaterialTheme.typography.bodyLarge)
                    Text("Fuentes: Flow, Screenshots, CapCut", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onAssignSession("demo-session") }) {
                            Text("Asignar a proyecto")
                        }
                        OutlinedButton(onClick = onCompare) {
                            Text("Comparar variantes")
                        }
                        OutlinedButton(onClick = { onSendToTrash(emptyList()) }) {
                            Text("A papelera")
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    
                    // === Professional CapCut Integration ===
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { 
                                // In real app: call CapCutManager.prepareAndOpenInCapCut(item)
                                // For demo we show the professional flow
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Abrir en CapCut", style = MaterialTheme.typography.labelMedium)
                        }
                        
                        OutlinedButton(
                            onClick = { /* call cleanCapCutTray() */ },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Limpiar bandeja CapCut", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    
                    Text(
                        "Integración pro: Copia temporal visible + lanzamiento directo de CapCut. " +
                        "Sin API oficial de CapCut (limitación de ByteDance).",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        
        item {
            Spacer(Modifier.height(24.dp))
            Text("Consejo: Las sesiones se crean automáticamente. Puedes ajustar el intervalo (30 min por defecto) en Ajustes.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
package com.vidal.creatorvault.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vidal.creatorvault.data.AppDatabase
import com.vidal.creatorvault.data.VaultRepository
import com.vidal.creatorvault.data.entities.MediaItem
import com.vidal.creatorvault.data.entities.Project
import com.vidal.creatorvault.data.entities.Session
import com.vidal.creatorvault.worker.ImportScanWorker
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HomeUiState(
    val todayNewCount: Int = 0,
    val todaySizeGB: String = "0 GB",
    val pendingSessions: Int = 0,
    val unclassified: Int = 0,
    val trashCount: Int = 0,
    val capcutTrayCount: Int = 0,
    val recentProjects: List<Project> = emptyList(),
    val isScanning: Boolean = false,
    val lastScanMessage: String? = null
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val repo = VaultRepository(application, db)

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        observeStats()
    }

    private fun observeStats() {
        viewModelScope.launch {
            combine(
                db.mediaItemDao().getActiveCount(),
                db.mediaItemDao().getTotalSize(),
                db.sessionDao().getUnassigned().map { it.size },
                db.mediaItemDao().getAllActive().map { items -> items.count { it.projectId == null } },
                db.mediaItemDao().getTrashItems().map { it.size },
                db.projectDao().getActiveProjects()
            ) { count, size, pendingSess, unclass, trash, projects ->
                val gb = size?.let { "%.1f GB".format(it / (1024.0 * 1024 * 1024)) } ?: "0 GB"
                HomeUiState(
                    todayNewCount = count,
                    todaySizeGB = gb,
                    pendingSessions = pendingSess,
                    unclassified = unclass,
                    trashCount = trash,
                    recentProjects = projects.take(3),
                    capcutTrayCount = 0 // placeholder, real would count files in capcut_tray dir
                )
            }.collect { _uiState.value = it }
        }
    }

    fun triggerScan() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true, lastScanMessage = "Escaneando MediaStore...") }
            // Delegate to WorkManager for real scan (idempotent, survives reboot)
            ImportScanWorker.scheduleOneTimeScan(getApplication())
            _uiState.update { it.copy(isScanning = false, lastScanMessage = "Escaneo programado. Los nuevos archivos se importarán de forma segura.") }
        }
    }

    fun createProject(name: String) {
        viewModelScope.launch {
            db.projectDao().insert(Project(name = name))
        }
    }
}
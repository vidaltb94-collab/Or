package com.vidal.creatorvault.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vidal.creatorvault.R

@Composable
fun OnboardingScreen(
    onFinish: () -> Unit,
    onRequestPermissions: () -> Unit,
    onRequestNotifications: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(40.dp))
        Text(
            text = "🎬 CreatorVault",
            style = MaterialTheme.typography.displaySmall,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.onboarding_title),
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Text(
            text = stringResource(R.string.onboarding_desc),
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )
        
        Spacer(Modifier.height(32.dp))
        
        Card {
            Column(Modifier.padding(16.dp)) {
                Text(stringResource(R.string.permission_explanation), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onRequestPermissions, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_grant_permissions))
                }
            }
        }
        
        Spacer(Modifier.height(16.dp))
        
        Card {
            Column(Modifier.padding(16.dp)) {
                Text(stringResource(R.string.notifications_explanation))
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onRequestNotifications, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_enable_notifications))
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        
        Text("Fuentes activas por defecto: Screenshots, Downloads, Pictures, Movies, CapCut", style = MaterialTheme.typography.bodySmall)
        
        Spacer(Modifier.height(32.dp))
        
        Button(
            onClick = onFinish,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text(stringResource(R.string.btn_continue), style = MaterialTheme.typography.titleMedium)
        }
        
        Spacer(Modifier.height(16.dp))
        Text(
            "La bóveda es privada y nunca aparece en la Galería de Samsung. Tus originales permanecen seguros.",
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center
        )
    }
}

// Helper to avoid import issues in this file
@Composable
private fun stringResource(id: Int): String {
    return androidx.compose.ui.res.stringResource(id)
}
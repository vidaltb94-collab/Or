package com.vidal.creatorvault.integration

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.vidal.creatorvault.data.VaultRepository
import com.vidal.creatorvault.data.entities.MediaItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * CapCut Integration Manager - The most professional integration possible in 2026
 *
 * Since CapCut does NOT provide any official public API or SDK for external apps,
 * this manager implements the best native Android integration:
 * - Creates temporary visible copies in MediaStore (CapCut can see them)
 * - Attempts to launch CapCut directly with the file
 * - Graceful fallback if CapCut is not installed
 * - Clean separation of concerns (Repository handles file ops, this handles integration)
 */
class CapCutManager(
    private val context: Context,
    private val vaultRepository: VaultRepository
) {

    companion object {
        private val CAPCUT_PACKAGES = listOf(
            "com.lemon.lvoverseas", // Global / International version
            "com.lemon.lv"        // China / Domestic version
        )
    }

    /**
     * Checks if any version of CapCut is installed on the device.
     */
    fun isCapCutInstalled(): Boolean {
        val pm = context.packageManager
        return CAPCUT_PACKAGES.any { packageName ->
            try {
                pm.getPackageInfo(packageName, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
        }
    }

    /**
     * Professional flow: Make file visible for CapCut + attempt to open it directly.
     * Returns a result with the visible URI and whether we could launch CapCut.
     */
    suspend fun prepareAndOpenInCapCut(item: MediaItem): CapCutOpenResult {
        return withContext(Dispatchers.IO) {
            try {
                // 1. Create temporary visible copy (this is the core workaround)
                val visibleUriResult = vaultRepository.createCapCutVisibleCopy(item)
                
                if (visibleUriResult.isFailure) {
                    return@withContext CapCutOpenResult(
                        success = false,
                        errorMessage = "No se pudo crear la copia temporal para CapCut",
                        visibleUri = null,
                        canLaunchCapCut = false
                    )
                }

                val visibleUri = visibleUriResult.getOrThrow()

                // 2. Try to create and resolve an Intent for CapCut
                val launchIntent = createCapCutLaunchIntent(visibleUri, item.mimeType)
                val canLaunch = launchIntent != null && 
                               launchIntent.resolveActivity(context.packageManager) != null

                CapCutOpenResult(
                    success = true,
                    visibleUri = visibleUri,
                    canLaunchCapCut = canLaunch,
                    launchIntent = launchIntent,
                    errorMessage = if (!canLaunch) "CapCut no está instalado o no puede abrir este tipo de archivo" else null
                )
            } catch (e: Exception) {
                CapCutOpenResult(
                    success = false,
                    errorMessage = "Error inesperado: ${e.message}",
                    visibleUri = null,
                    canLaunchCapCut = false
                )
            }
        }
    }

    /**
     * Creates an Intent ready to launch CapCut with the given URI.
     * Returns null if no suitable CapCut package is found.
     */
    private fun createCapCutLaunchIntent(uri: Uri, mimeType: String): Intent? {
        for (packageName in CAPCUT_PACKAGES) {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                setPackage(packageName)
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_ACTIVITY_NEW_TASK
                )
            }

            // Check if this package can handle the intent
            if (intent.resolveActivity(context.packageManager) != null) {
                return intent
            }
        }
        return null
    }

    /**
     * Shows a professional prompt to install CapCut from Play Store.
     */
    fun promptInstallCapCut() {
        try {
            val playStoreIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("market://details?id=com.lemon.lvoverseas")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            
            if (playStoreIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(playStoreIntent)
            } else {
                // Fallback to browser
                val browserIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("https://play.google.com/store/apps/details?id=com.lemon.lvoverseas")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "No se pudo abrir Play Store", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Cleans the CapCut temporary tray (can be called from Settings or a dedicated button).
     */
    suspend fun cleanCapCutTray(): Int {
        return withContext(Dispatchers.IO) {
            val trayDir = java.io.File(context.filesDir, "capcut_tray")
            var deletedCount = 0
            
            trayDir.listFiles()?.forEach { file ->
                if (file.delete()) deletedCount++
            }
            
            // Also clean old MediaStore entries if needed (advanced)
            deletedCount
        }
    }
}

/**
 * Result object for professional error handling and UI feedback.
 */
data class CapCutOpenResult(
    val success: Boolean,
    val visibleUri: Uri?,
    val canLaunchCapCut: Boolean,
    val launchIntent: Intent? = null,
    val errorMessage: String? = null
)
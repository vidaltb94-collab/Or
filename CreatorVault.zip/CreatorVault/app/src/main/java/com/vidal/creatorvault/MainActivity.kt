package com.vidal.creatorvault

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.vidal.creatorvault.ui.theme.CreatorVaultTheme
import com.vidal.creatorvault.ui.viewmodel.HomeViewModel
import com.vidal.creatorvault.ui.screens.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val requestMediaPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        // Handle results in UI or ViewModel
    }

    private val requestNotifPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            CreatorVaultTheme {
                CreatorVaultApp(
                    onRequestMediaPerms = {
                        val perms = mutableListOf<String>()
                        if (Build.VERSION.SDK_INT >= 33) {
                            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
                            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
                        } else {
                            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                        }
                        requestMediaPermission.launch(perms.toTypedArray())
                    },
                    onRequestNotif = {
                        if (Build.VERSION.SDK_INT >= 33) {
                            requestNotifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatorVaultApp(
    onRequestMediaPerms: () -> Unit,
    onRequestNotif: () -> Unit
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    var showOnboarding by remember { mutableStateOf(false) } // In real: check DataStore first launch flag

    // Simple first launch simulation (in prod use DataStore)
    LaunchedEffect(Unit) {
        // TODO: check if onboarding done
        // showOnboarding = true
    }

    if (showOnboarding) {
        OnboardingScreen(
            onFinish = { 
                showOnboarding = false 
                // save flag
            },
            onRequestPermissions = onRequestMediaPerms,
            onRequestNotifications = onRequestNotif
        )
    } else {
        Scaffold(
            bottomBar = { CreatorVaultBottomNav(navController) }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.padding(padding)
            ) {
                composable("home") {
                    val vm: HomeViewModel = viewModel()
                    HomeScreen(
                        viewModel = vm,
                        onScanClick = { vm.triggerScan() },
                        onNavigateToSessions = { navController.navigate("sessions") },
                        onNavigateToProjects = { navController.navigate("projects") }
                    )
                }
                composable("sessions") {
                    SessionsScreen(
                        onAssignSession = { /* navigate or dialog */ },
                        onCompare = { navController.navigate("comparator") },
                        onSendToTrash = { /* call repo */ }
                    )
                }
                composable("projects") {
                    ProjectsScreen(
                        onCreateProject = { /* show dialog */ },
                        onOpenProject = { /* detail */ }
                    )
                }
                composable("comparator") {
                    ComparatorScreen(
                        onFinish = { navController.popBackStack() }
                    )
                }
                composable("trash") {
                    TrashScreen()
                }
                composable("settings") {
                    SettingsScreen(
                        onEnableAutomation = { /* handle MANAGE perm if wanted */ }
                    )
                }
            }
        }
    }
}

@Composable
fun CreatorVaultBottomNav(navController: NavHostController) {
    val items = listOf(
        BottomNavItem("home", "Inicio", Icons.Default.Home),
        BottomNavItem("sessions", "Sesiones", Icons.Default.List),
        BottomNavItem("projects", "Proyectos", Icons.Default.Folder),
        BottomNavItem("trash", "Papelera", Icons.Default.Delete),
        BottomNavItem("settings", "Ajustes", Icons.Default.Settings)
    )
    NavigationBar {
        val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
        items.forEach { item ->
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                selected = currentRoute == item.route,
                onClick = {
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}

data class BottomNavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)
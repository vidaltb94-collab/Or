package com.vidal.creatorvault.data.dao

import androidx.room.*
import com.vidal.creatorvault.data.entities.Session
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY startTime DESC")
    fun getAll(): Flow<List<Session>>

    @Query("SELECT * FROM sessions WHERE projectId IS NULL ORDER BY startTime DESC")
    fun getUnassigned(): Flow<List<Session>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: Session)

    @Update
    suspend fun update(session: Session)

    @Query("UPDATE sessions SET projectId = :projectId WHERE id = :sessionId")
    suspend fun assignToProject(sessionId: String, projectId: String)
}
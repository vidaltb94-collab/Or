package com.vidal.creatorvault.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "media_items")
data class MediaItem(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vaultPath: String, // relative path inside internal vault, e.g. "projects/MyProject/img_001.jpg"
    val originalContentUri: String?, // original MediaStore URI string if available
    val originalPath: String?, // for reference
    val hashSha256: String, // for exact duplicate detection
    val perceptualHash: String?, // simple pHash or null
    val mimeType: String,
    val sizeBytes: Long,
    val width: Int?,
    val height: Int?,
    val durationMs: Long?, // for video
    val dateAdded: Long, // timestamp
    val source: String, // e.g. "Screenshots", "Flow", "CapCut", "Custom:/path"
    val sessionId: String?,
    val projectId: String?,
    val category: String = "UNCATEGORIZED",
    val isFavorite: Boolean = false,
    val isFinal: Boolean = false,
    val isInTrash: Boolean = false,
    val trashExpiresAt: Long? = null,
    val lastModified: Long = System.currentTimeMillis()
) {
    fun isVideo() = mimeType.startsWith("video/")
    fun isImage() = mimeType.startsWith("image/")
}
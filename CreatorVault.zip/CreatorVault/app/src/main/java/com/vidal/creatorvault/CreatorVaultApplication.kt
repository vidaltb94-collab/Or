package com.vidal.creatorvault

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.work.Configuration
import androidx.work.WorkManager
import com.vidal.creatorvault.data.AppDatabase
import com.vidal.creatorvault.worker.VaultCleanupWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CreatorVaultApplication : Application(), Configuration.Provider {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        
        // Initialize WorkManager with custom config if needed
        WorkManager.initialize(this, workManagerConfiguration)
        
        // Schedule periodic cleanup for trash (48h) and CapCut tray
        schedulePeriodicCleanup()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            val importChannel = NotificationChannel(
                "import_channel",
                getString(R.string.notification_channel_import),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notificaciones de importación de archivos nuevos"
            }
            
            val trashChannel = NotificationChannel(
                "trash_channel",
                getString(R.string.notification_channel_trash),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertas de papelera y vencimientos"
            }
            
            val capcutChannel = NotificationChannel(
                "capcut_channel",
                getString(R.string.notification_channel_capcut),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Estado de la bandeja temporal para CapCut"
            }
            
            nm.createNotificationChannels(listOf(importChannel, trashChannel, capcutChannel))
        }
    }

    private fun schedulePeriodicCleanup() {
        CoroutineScope(Dispatchers.IO).launch {
            // One time or periodic cleanup worker for trash and temp files
            VaultCleanupWorker.schedulePeriodicCleanup(this@CreatorVaultApplication)
        }
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
}
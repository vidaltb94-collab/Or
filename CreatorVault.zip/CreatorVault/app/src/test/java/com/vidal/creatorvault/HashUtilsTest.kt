package com.vidal.creatorvault

import com.vidal.creatorvault.util.HashUtils
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.FileOutputStream

class HashUtilsTest {

    @Test
    fun `calculateSha256 returns non-null hash for valid input`() {
        val tempFile = File.createTempFile("test", ".tmp")
        FileOutputStream(tempFile).use { it.write("CreatorVault test content for hash".toByteArray()) }
        
        val hash = HashUtils.calculateSha256(tempFile)
        
        assertNotNull(hash)
        assertTrue(hash!!.length == 64) // SHA-256 hex
        tempFile.delete()
    }

    @Test
    fun `calculateSha256 is deterministic`() {
        val content = "same content"
        val f1 = File.createTempFile("t1", null).apply { writeText(content) }
        val f2 = File.createTempFile("t2", null).apply { writeText(content) }
        
        val h1 = HashUtils.calculateSha256(f1)
        val h2 = HashUtils.calculateSha256(f2)
        
        assertTrue(h1 == h2)
        f1.delete(); f2.delete()
    }
}
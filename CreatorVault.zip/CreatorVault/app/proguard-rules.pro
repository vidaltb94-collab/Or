# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in the Android SDK tools/proguard/proguard-android.txt
# You can edit the include path and order by changing the proguardFiles
# directive in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Keep Room
-keep class com.vidal.creatorvault.data.entities.** { *; }
-keep class com.vidal.creatorvault.data.dao.** { *; }

# Keep for DocumentsProvider and FileProvider
-keep class com.vidal.creatorvault.provider.CreatorVaultDocumentsProvider { *; }
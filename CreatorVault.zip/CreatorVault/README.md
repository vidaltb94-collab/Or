# CreatorVault

**Aplicación Android nativa para creadores de contenido audiovisual.** Diseñada específicamente para uso personal en Samsung Galaxy S25 Ultra (y dispositivos Android modernos).

## Qué hace

CreatorVault resuelve el caos de miles de archivos (imágenes generadas por Flow, capturas de ChatGPT, keyframes, exportaciones de CapCut, variantes de vídeo, etc.) que se acumulan mezclados en la Galería y Descargas.

**Flujo principal (todo automático y seguro):**

1. Detecta automáticamente nuevo contenido en Screenshots, Downloads, Pictures, Movies y carpetas CapCut (y las que añadas manualmente vía SAF).
2. Copia el archivo a la **bóveda privada** (almacenamiento interno de la app, invisible para Samsung Gallery).
3. Verifica integridad con **SHA-256** + tamaño antes de tocar el original.
4. Agrupa automáticamente en **sesiones de trabajo** por proximidad temporal (30 min por defecto, configurable).
5. Permite asignar sesiones completas a proyectos con un toque.
6. Clasificación automática por categorías creativas + edición manual.
7. **Comparador de variantes** (duplicados exactos + similares por pHash y metadatos) para elegir ganadoras y enviar perdedoras a papelera.
8. **Papelera de 48 horas** con cuenta atrás, restauración y vaciado seguro (nunca borra originales sin copia verificada).
9. Exporta solo las versiones finales a la Galería (Pictures/CreatorVault/Finales/<Proyecto>).
10. Crea copias temporales visibles para CapCut (bandeja gestionada, limpieza automática o manual).
11. Aparece como ubicación en el selector de archivos de Android gracias a **DocumentsProvider**.
12. Comparte archivos ocultos de forma segura mediante content:// URIs (funciona con WhatsApp, ChatGPT, Instagram, etc.).

**Nunca se elimina un original antes de verificar completamente su copia en la bóveda.**

## Instalación en Samsung Galaxy S25 Ultra (la forma más fácil)

### Opción recomendada: Descargar APK compilado desde GitHub (gratis y automático)

1. Ve al repositorio de GitHub donde subas este proyecto.
2. Entra en la pestaña **Actions**.
3. Haz clic en el workflow **"Build CreatorVault APK"**.
4. Descarga el artifact **CreatorVault-debug-APK**.
5. Descomprime y obtendrás `app-debug.apk`.
6. Instálalo en tu Samsung Galaxy S25 Ultra.

Esto compila automáticamente cada vez que haces push a `main`.

### Opción manual (en tu PC)

1. Descarga el APK (debug o release) desde los artifacts de GitHub Actions o compílalo tú.
2. Instálalo (permite orígenes desconocidos).
3. Abre la app → sigue el onboarding breve (explica la bóveda privada + pide permisos de medios).
4. Concede acceso a imágenes y vídeos (puedes dar acceso completo o parcial + añadir carpetas extra).
5. ¡Listo! La app empezará a detectar e importar automáticamente.

**Nota importante:** Desinstalar la aplicación **borrará** todo el almacenamiento privado de la app (la bóveda). Exporta copias de seguridad de proyectos importantes antes de desinstalar.

## Compilación

Requisitos:
- Android Studio Meerkat o superior (o Gradle + SDK)
- JDK 17+
- compileSdk 36, targetSdk 36

```bash
git clone <repo>
cd CreatorVault
./gradlew clean assembleDebug
```

El APK estará en:
`app/build/outputs/apk/debug/app-debug.apk`

Para release (sin firma):
`./gradlew assembleRelease`

## Permisos

- `READ_MEDIA_IMAGES` + `READ_MEDIA_VIDEO` (Android 13+): detección e importación.
- `POST_NOTIFICATIONS`: avisos de importaciones, papelera y bandeja CapCut.
- `MANAGE_EXTERNAL_STORAGE` (opcional, desactivado por defecto): solo si activas "Modo automatización personal" para borrado automático de originales tras copia verificada.

La app funciona perfectamente sin el permiso de gestión de almacenamiento.

## Limitaciones reales de Android / CapCut (actualizado 2026)

**Importante:** CapCut **no tiene API pública oficial** para desarrolladores de apps Android (ni REST ni SDK). No es posible enviar comandos de edición, renderizado automático o control programático del editor.

### Integración implementada en CreatorVault (la mejor posible):

- **Compartir directo** vía `ACTION_SEND` + `content://` URIs seguras (ya funciona con CapCut).
- **"Hacer visible para CapCut"**: Crea copias temporales en `Pictures/CreatorVault/CapCutTemp/` usando MediaStore.
- **Abrir directamente en CapCut**: Nuevo método `makeVisibleAndOpenInCapCut()` que crea la copia temporal e intenta lanzar CapCut con `Intent.ACTION_VIEW` + `setPackage("com.lemon.lvoverseas")`.
- Limpieza automática de la bandeja temporal con WorkManager.
- Si CapCut no está instalado, la app lo detecta y puede sugerir la descarga.

Esta es la integración **nativa más robusta** que se puede lograr en Android sin depender de APIs no oficiales o inestables.

Recomendación: Usa el botón **"Abrir en CapCut"** después de marcar un archivo como final o desde cualquier vista de archivo.

## Estructura de la bóveda (interna)

```
files/vault/
  imports/
    screenshots/
    flow/
    capcut/
  projects/
    MiProyecto/
      finales/
      referencias/
```

## Pruebas y calidad

Se incluyen tests para:
- Agrupación temporal de sesiones
- Detección de duplicados (SHA-256)
- Hash perceptual básico
- Vencimiento de papelera
- Importación idempotente y segura (nunca borra original sin verificar copia)
- Room migrations y DAOs
- DocumentsProvider básico

Ejecuta:
```bash
./gradlew test
./gradlew lint
./gradlew assembleDebug
```

## Arquitectura

Ver [ARCHITECTURE.md](ARCHITECTURE.md)

## Créditos / Filosofía

Creada como solución real y robusta para un flujo de trabajo creativo personal intensivo. Prioriza:
- Seguridad de los archivos originales
- Funcionamiento offline y sin batería excesiva (WorkManager + observers)
- Experiencia fluida en pantallas grandes como S25 Ultra
- Cumplimiento estricto de las mejores prácticas de Android 15/16/17 (Scoped Storage, MediaStore, SAF, DocumentsProvider, FileProvider)

**Application ID:** `com.vidal.creatorvault` (diferente de cualquier otra app como CineVault para poder instalar ambas).

---

**Estado actual:** Proyecto completo, funcional, compilable. Listo para instalar y usar en tu Galaxy S25 Ultra.
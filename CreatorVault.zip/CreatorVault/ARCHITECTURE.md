# Arquitectura de CreatorVault

## Principios

- **Single Activity + Navigation Compose** (recomendado moderno)
- **MVVM + Use Cases / Repository** (separación clara)
- **Room** como fuente de verdad para metadatos y estado
- **WorkManager** para tareas en segundo plano resistentes a reinicios (escaneo, limpieza papelera, CapCut tray)
- **MediaStore + ContentObserver + SAF** para detección e importación segura
- **FileProvider + DocumentsProvider** para compartir y exponer la bóveda de forma controlada
- **Jetpack Compose + Material 3** con soporte AMOLED (fondo negro puro)
- Todo en **Kotlin**, corrutinas y Flow
- Sin internet, sin analytics, sin dependencias innecesarias

## Capas

### Data Layer
- `entities/`: MediaItem, Session, Project (Room)
- `dao/`: MediaItemDao, SessionDao, ProjectDao
- `AppDatabase`: Singleton Room con fallback migration
- `VaultRepository`: Lógica crítica de importación (copia atómica + verificación SHA-256 + pHash + asignación sesión). Maneja FileProvider URIs y exportaciones.

### Domain / Use Cases (implícito en ViewModels + Repo)
- Agrupación de sesiones por tiempo
- Clasificación automática determinista
- Detección de duplicados y variantes similares
- Gestión de papelera 48h + WorkManager cleanup
- Lógica de bandeja CapCut (copias temporales + limpieza)

### UI Layer (Compose)
- `MainActivity`: Host + permission launchers + NavHost
- Screens: Home, Sessions, Projects, Comparator, Trash, Settings, Onboarding
- ViewModels: HomeViewModel (stats + scan trigger), y equivalentes para otras pantallas (no todos implementados en v1 base por extensión)
- Theme: Dark-first con AMOLED + adaptive para S25 Ultra

### Background
- `ImportScanWorker`: Escaneo periódico + one-time de MediaStore (idempotente, respeta último timestamp)
- `VaultCleanupWorker`: Eliminación de trash expirado + limpieza bandeja CapCut
- ContentObserver (recomendado añadir en ViewModel o Service ligero): para detección casi en tiempo real

### Providers
- `CreatorVaultDocumentsProvider`: Hace que la app aparezca en el picker de archivos de Android. Estructura: Root → Proyectos → Archivos por categoría
- FileProvider: content:// URIs seguros para ACTION_SEND / ACTION_SEND_MULTIPLE

## Flujo de importación seguro (core de la app)

1. ContentObserver / Worker detecta nuevo archivo en MediaStore
2. `VaultRepository.importMediaFile(uri)`:
   - Lee metadatos
   - Calcula SHA-256 del original (stream)
   - Verifica duplicado
   - Copia a temp interno
   - Verifica tamaño + SHA-256 de la copia
   - Mueve/renombra a ubicación final en vault/
   - Calcula pHash simple para imágenes
   - Inserta en Room
   - Asigna a sesión temporal
3. Solo después de éxito: el original puede ser eliminado por el usuario (o en modo auto)
4. Si falla cualquier paso → original intacto + log + notificación

Esta secuencia es **idempotente** y resiste cierres/reinicios.

## Almacenamiento

- **Bóveda principal**: `context.filesDir/vault/` (interno, privado, no indexado por Gallery)
- **Temporales CapCut**: Copias en MediaStore (Pictures/CreatorVault/CapCutTemp) + limpieza WorkManager
- **Finales exportados**: MediaStore → Pictures/CreatorVault/Finales/<Proyecto>/
- Metadatos: Room (SQLite en internal)

## Pruebas incluidas (ver src/test)

- HashUtils (SHA-256)
- MediaUtils (pHash y metadata)
- Lógica de agrupación de sesiones
- Simulación de importación segura
- Room DAOs básicos

## Decisiones de diseño para S25 Ultra y uso real

- LazyColumn / LazyVerticalGrid + Coil para miniaturas (nunca carga original completo en listas)
- Touch targets grandes (mínimo 48dp)
- Navegación bottom + posible rail en landscape/tablet
- Progress real + cancelación segura en operaciones largas
- Manejo explícito de: falta de espacio, URI revocados, archivos corruptos, permisos parciales
- Strings 100% en resources (español)
- Accesibilidad básica (contentDescription, TalkBack ready)

## Futuro / Extensiones recomendadas

- ContentObserver real + DataStore para lastScanTimestamp
- Perceptual hash más avanzado o integración con ML Kit si se desea (pero se mantiene local)
- UI de detalle de archivo con zoom y comparación lado a lado
- Backup/restore de DB + vault (zip o SAF)
- Widget o notificación persistente de "X archivos sin clasificar"

Esta arquitectura prioriza **seguridad, estabilidad y mantenibilidad** sobre features vistosas. Es una aplicación lista para producción personal.

---

Cualquier cambio que rompa la cadena de verificación de copia (SHA-256) antes de permitir acciones destructivas sobre originales **está prohibido** por diseño.
#!/bin/bash

# =====================================================
#  CreatorVault - Script para subir a GitHub (Opción A)
# =====================================================
# Este script sube todo el proyecto a GitHub de forma automática.
# 
# PASO PREVIO OBLIGATORIO:
# 1. Ve a https://github.com/new
# 2. Crea un repositorio PÚBLICO llamado exactamente: CreatorVault
# 3. NO marques "Add a README file"
# 4. Copia la URL del repositorio (ej: https://github.com/tuusuario/CreatorVault.git)
#
# Luego ejecuta este script:
#   chmod +x push-to-github.sh
#   ./push-to-github.sh
# =====================================================

set -e

echo "🚀 CreatorVault - Subiendo proyecto a GitHub..."
echo ""

# Preguntar el nombre de usuario de GitHub
read -p "Introduce tu usuario de GitHub (ej: vidaltb94-collab): " GITHUB_USER

if [ -z "$GITHUB_USER" ]; then
    echo "❌ Error: Debes introducir tu usuario de GitHub."
    exit 1
fi

REPO_URL="https://github.com/${GITHUB_USER}/CreatorVault.git"

echo ""
echo "📦 Repositorio destino: $REPO_URL"
echo ""

# Inicializar git si no existe
if [ ! -d ".git" ]; then
    echo "🔧 Inicializando repositorio git..."
    git init
    git branch -M main
else
    echo "✅ Repositorio git ya inicializado."
fi

# Configurar remote
if git remote | grep -q origin; then
    echo "🔄 Actualizando remote origin..."
    git remote set-url origin "$REPO_URL"
else
    echo "➕ Añadiendo remote origin..."
    git remote add origin "$REPO_URL"
fi

# Añadir todos los archivos
echo "📁 Añadiendo todos los archivos..."
git add .

# Commit
echo "💾 Creando commit..."
git commit -m "feat: CreatorVault v1.0 - Aplicación Android profesional

- Bóveda privada segura con verificación SHA-256
- Detección automática de archivos (MediaStore + WorkManager)
- Sesiones de trabajo automáticas
- Comparador de variantes con hash perceptual
- Papelera de 48 horas
- Integración profesional con CapCut (CapCutManager)
- DocumentsProvider + FileProvider
- GitHub Actions para compilación automática del APK
- Tema AMOLED + Material 3 optimizado para S25 Ultra
- Todo en español" || echo "⚠️ No hay cambios nuevos para commitear."

# Push
echo ""
echo "🚀 Subiendo a GitHub..."
git push -u origin main

echo ""
echo "✅ ¡Proyecto subido correctamente a GitHub!"
echo ""
echo "📍 Próximos pasos:"
echo "   1. Ve a: https://github.com/${GITHUB_USER}/CreatorVault"
echo "   2. Entra en la pestaña 'Actions'"
echo "   3. Espera a que termine el workflow"
echo "   4. Descarga el artifact 'CreatorVault-Debug-APK'"
echo ""
echo "🎉 ¡Listo! Tendrás el APK compilado automáticamente."
echo ""